## frontend is in app
## Just do `npm install` and then `npm run dev`